<br></br>

<div class="content-box">
	<div class="row">
		<div class="col">
			<h4>Admin Panel Setting</h4>
		</div>
	</div>
	<br>
	<div class="row">
		<div class="col">
			<a href="dashboard.php?cat=setting&subcat=color-setting" class="btn btn-secondary content-link text-light">Color Setting</a>
		</div>

	</div>
</div>