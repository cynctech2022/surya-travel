<?php include("header.php")?>
<style type="text/css">
	.service-img{
		height:120px;
		width: 120px;
	}
	.service-card-hr{
		color: #fd6346;
    padding: 3px;
    width: 25%;
    text-align: center;
    margin: -5% 0px 0px 38%;
	}
	.service-btn{
		border-radius:10px;
	}
</style>
<div class="breatcome_area d-flex align-items-center">
   <div class="container">
      <div class="row">
         <div class="col-lg-12">
            <div class="breatcome_title">
               <div class="breatcome_title_inner pb-2">
                  <h2>Service</h2>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<section class="service" id="service">
   <div class="container">
      <div class="row">
         <div class="col-lg-4 col-md-4 col-sm-12 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="service-card">
               <div class="card mb-5" style="width: 20rem;">
               	<div class= "text-center my-3">
               	<hr class="service-card-hr">
               </div>
                  <img class="card-img-top service-img" src="assets/img/service-img.png" alt="Card image cap">
                  <div class="card-body">
                     <h5 class="card-title py-2">Bus Ticket Service</h5>
                     <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                     tempor incididunt ut labore et dolore magna aliqua. </p>
                     <a href="#" class="btn service-btn text-white">Enquiry Now</a>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
             <div class="service-card">
               <div class="card mb-5" style="width: 20rem;">
               	<div class= "text-center my-3">
               	<hr class="service-card-hr">
               </div>
                  <img class="card-img-top service-img" src="assets/img/service-img.png" alt="Card image cap">
                  <div class="card-body">
                     <h5 class="card-title py-2">Bus Ticket Service</h5>
                     <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                     tempor incididunt ut labore et dolore magna aliqua. </p>
                     <a href="#" class="btn service-btn text-white">Enquiry Now</a>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="300">
             <div class="service-card">
               <div class="card mb-5" style="width: 20rem;">
               	<div class= "text-center my-3">
               	<hr class="service-card-hr">
               </div>
                  <img class="card-img-top service-img" src="assets/img/service-img.png" alt="Card image cap">
                  <div class="card-body">
                     <h5 class="card-title py-2">Bus Ticket Service</h5>
                     <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                     tempor incididunt ut labore et dolore magna aliqua. </p>
                     <a href="#" class="btn service-btn text-white">Enquiry Now</a>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="400">
         	 <div class="service-card">
               <div class="card mb-5" style="width: 20rem;">
               	<div class= "text-center my-3">
               	<hr class="service-card-hr">
               </div>
                  <img class="card-img-top service-img" src="assets/img/service-img.png" alt="Card image cap">
                  <div class="card-body">
                     <h5 class="card-title py-2">Bus Ticket Service</h5>
                     <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                     tempor incididunt ut labore et dolore magna aliqua. </p>
                     <a href="#" class="btn service-btn text-white">Enquiry Now</a>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="500">
             <div class="service-card">
               <div class="card mb-5" style="width: 20rem;">
               	<div class= "text-center my-3">
               	<hr class="service-card-hr">
               </div>
                  <img class="card-img-top service-img" src="assets/img/service-img.png" alt="Card image cap">
                  <div class="card-body">
                     <h5 class="card-title py-2">Bus Ticket Service</h5>
                     <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                     tempor incididunt ut labore et dolore magna aliqua. </p>
                     <a href="#" class="btn service-btn text-white">Enquiry Now</a>
                  </div>
               </div>
            </div>         </div>
         <div class="col-lg-4 col-md-4 col-sm-12 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="600">
             <div class="service-card">
               <div class="card mb-5" style="width: 20rem;">
               	<div class= "text-center my-3">
               	<hr class="service-card-hr">
               </div>
                  <img class="card-img-top service-img" src="assets/img/service-img.png" alt="Card image cap">
                  <div class="card-body">
                     <h5 class="card-title py-2">Bus Ticket Service</h5>
                     <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                     tempor incididunt ut labore et dolore magna aliqua. </p>
                     <a href="#" class="btn service-btn text-white">Enquiry Now</a>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="700">
             <div class="service-card">
               <div class="card mb-5" style="width: 20rem;">
               	<div class= "text-center my-3">
               	<hr class="service-card-hr">
               </div>
                  <img class="card-img-top service-img" src="assets/img/service-img.png" alt="Card image cap">
                  <div class="card-body">
                     <h5 class="card-title py-2">Bus Ticket Service</h5>
                     <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                     tempor incididunt ut labore et dolore magna aliqua. </p>
                     <a href="#" class="btn service-btn text-white">Enquiry Now</a>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="800">
             <div class="service-card">
               <div class="card mb-5" style="width: 20rem;">
               	<div class= "text-center my-3">
               	<hr class="service-card-hr">
               </div>
                  <img class="card-img-top service-img" src="assets/img/service-img.png" alt="Card image cap">
                  <div class="card-body">
                     <h5 class="card-title py-2">Bus Ticket Service</h5>
                     <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                     tempor incididunt ut labore et dolore magna aliqua. </p>
                     <a href="#" class="btn service-btn text-white">Enquiry Now</a>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="900">
            <div class="service-card">
               <div class="card mb-5" style="width: 20rem;">
               	<div class= "text-center my-3">
               	<hr class="service-card-hr">
               </div>
                  <img class="card-img-top service-img" src="assets/img/service-img.png" alt="Card image cap">
                  <div class="card-body">
                     <h5 class="card-title py-2">Bus Ticket Service</h5>
                     <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                     tempor incididunt ut labore et dolore magna aliqua. </p>
                     <a href="#" class="btn service-btn text-white">Enquiry Now</a>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<?php include("footer.php")?>