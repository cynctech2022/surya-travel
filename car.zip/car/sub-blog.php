<?php include("header.php")?>
<section id="blog" class="  blog" >
   <div class="container">
      <div class="row">
         <div class="col-lg-12 col-md-12 col-sm-12">
            <h2 class="text-center text-white  my-5">Blog</h2>

         </div>
      </div>
   </div>
</section>
<section class="sub-blog">
   <div class="container">
      <div class="row my-5">
         <div class="col-lg-6 col-md-6 col-sm-12 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="">
               <h2 class="">Best Car Rental service</h2>
               <hr class="sub-blog-hr" style="width: 65%;">
               <p class="py-2">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                  tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                  quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                  consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                  cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                  proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
               </p>
            </div>
         </div>
         <div class="col-lg-6 col-md-6 col-sm-12 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="">
               <img src="assets/img/blog-img.jpg" alt="blog img" class="sub-blog-img px-5">
            </div>
         </div>
      </div>
      <div class="col-lg-12 col-md-12 col-sm-12 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
         <div class="">
            <h3>Car Facility</h3>
            <hr class="sub-blog-hr" style="width: 18%;">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
               tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
               quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
               consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
               cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
               proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
         </div>
      </div>
  
   <div class="row my-3">
      <div class="col-lg-6 col-md-6 col-sm-12 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="300">
         <div class="">
            <img src="assets/img/blog-img.jpg" alt="blog img" class="sub-blog-img">
         </div>
      </div>
      <div class="col-lg-6 col-md-6 col-sm-12 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="300">
         <div class="">
            <h3>Car Facility</h3>
            <hr class="sub-blog-hr">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
               tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
               quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
               consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
               cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
               proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
         </div>
      </div>
      
      <div class="col-lg-12 col-md-12 col-sm-12 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="400">
         <div class="my-5">
            <h3 class="py-2">Car Facility</h3>
            <hr class="sub-blog-hr" style="width: 18%;">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
               tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
               quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
               consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
               cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
               proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
         </div>
      </div>
      <div class="col-lg-12 col-md-12 col-sm-12 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="500">
         <div class="">
            <h3>Car Facility</h3>
            <hr class="sub-blog-hr" style="width: 18%;">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
               tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
               quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
               consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
               cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
               proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
         </div>
      </div>
   </div>
   </div>
</section>
<?php include("footer.php")?>