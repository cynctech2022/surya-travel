<?php include("header.php")?>
<br><br>
<div class="breatcome_area d-flex align-items-center">
   <div class="container">
      <div class="row">
         <div class="col-lg-12">
            <div class="breatcome_title">
               <div class="breatcome_title_inner pb-2">
                  <h2>Blogs</h2>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<section class="blog-section  my-5">
   <div class="container" >
   <div class="row">
      <!--  <div class="col-lg-4  col-sm-12"> -->
      <div class="col-lg-4 col-sm-12 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
         <div class="card blog-card zoom" style="width: 20rem;">
            <div class="member-img">
               <img src="assets/img/blog5.png" class="img-fluid blog-img" alt="">
            </div>
            <div class="blog-info ml-4">
               <p class="blog-date ">1/04/2020</p>
            </div>
            <div class="card-body">
               <div class="member">
                  <div class="member-info">
                     <h4 class="blog-title">Best Car Rental service</h4>
                     <p class="blog-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis </p>
                     <div class="row">
                        <div class="col-md-12">
                           <div class="">
                              <a href="sub-blog.php">
                                 <p class="text-dark"><b>Read More</b></p>
                              </a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="col-lg-4 col-md-4 col-sm-12 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
         <div class="card blog-card  zoom" style="width: 20rem;">
            <div class="member-img">
               <img src="assets/img/blog5.png" class="img-fluid blog-img" alt="">
            </div>
            <div class="blog-info">
               <p class="blog-date">1/04/2020</p>
            </div>
            <div class="card-body">
               <div class="member">
                  <div class="member-info">
                     <h4 class="blog-title">Best Car Rental service</h4>
                     <p class="blog-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis </p>
                     <div class="row">
                        <div class="col-md-12">
                           <div class="">
                              <a href="sub-blog.php">
                                 <p class="text-dark"><b>Read More</b></p>
                              </a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="col-lg-4 col-md-4 col-sm-12 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="300">
         <div class="card blog-card  zoom" style="width: 20rem;">
            <div class="member-img">
               <img src="assets/img/blog5.png" class="img-fluid blog-img" alt="">
            </div>
            <div class="blog-info">
               <p class="blog-date">1/04/2020</p>
            </div>
            <div class="card-body">
               <div class="member">
                  <div class="member-info">
                     <h4 class="blog-title">Best Car Rental service</h4>
                     <p class="blog-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis </p>
                     <div class="row">
                        <div class="col-md-12">
                           <div class="">
                              <a href="sub-blog.php">
                                 <p class="text-dark"><b>Read More<b></p>
                              </a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="row py-5">
      <div class="col-lg-4 col-md-4 col-sm-12 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
         <div class="card blog-card  zoom" style="width: 20rem;">
            <div class="member-img">
               <img src="assets/img/blog5.png" class="img-fluid blog-img" alt="">
            </div>
            <div class="blog-info">
               <p class="blog-date">1/04/2020</p>
            </div>
            <div class="card-body">
               <div class="member">
                  <div class="member-info">
                     <h4 class="blog-title">Best Car Rental service</h4>
                     <p class="blog-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis </p>
                     <div class="row">
                        <div class="col-md-12">
                           <div class="">
                              <a href="sub-blog.php">
                                 <p class="text-dark"><b>Read More</b></p>
                              </a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="col-lg-4 col-md-4 col-sm-12 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
         <div class="card blog-card  zoom" style="width: 20rem;">
            <div class="member-img">
               <img src="assets/img/blog5.png" class="img-fluid blog-img" alt="">
            </div>
            <div class="blog-info">
               <p class="blog-date">1/04/2020</p>
            </div>
            <div class="card-body">
               <div class="member">
                  <div class="member-info">
                     <h4 class="blog-title">Best Car Rental service</h4>
                     <p class="blog-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis </p>
                     <div class="row">
                        <div class="col-md-12">
                           <div class="">
                              <a href="sub-blog.php">
                                 <p class="text-dark"><b>Read More</b></p>
                              </a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="col-lg-4 col-md-4 col-sm-12 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="300">
         <div class="card blog-card  zoom" style="width: 20rem;">
            <div class="member-img">
               <img src="assets/img/blog5.png" class="img-fluid blog-img" alt="">
            </div>
            <div class="blog-info">
               <p class="blog-date">1/04/2020</p>
            </div>
            <div class="card-body">
               <div class="member">
                  <div class="member-info">
                     <h4 class="blog-title">Best Car Rental service</h4>
                     <p class="blog-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis </p>
                     <div class="row">
                        <div class="col-md-12">
                           <div class="">
                              <a href="sub-blog.php">
                                 <p class="text-dark"><b>Read More</b></p>
                              </a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="col-lg-12">
         <div class="text-center my-4">
            <button class="px-5 text-white btn">View All</button>
         </div>
      </div>
   </div>
</section>
<?php include("footer.php")?>